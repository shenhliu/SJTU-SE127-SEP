#include "Editor.h"

//Lab3: you do not need to modify this file.

int main()
{
    Editor ed;
    ed.run();
    return 0;
}